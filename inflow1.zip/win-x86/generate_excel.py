import xlsxwriter
import random
import pandas as pd
from datetime import datetime
from bs4 import BeautifulSoup
import numpy as np
import os
df = pd.read_csv('AllDetails.csv')
with open("InflowForecast.dll.config", "r") as file:
    # Read each line in the file, readlines() returns a list of lines
    content = file.readlines()
    # Combine the lines in the list into a string
    content = "".join(content)
    #print(content)
    bs_content = BeautifulSoup(content)
    CSV_location=bs_content.find("add", {"key": "locationOfcsv"}).get('value')  
    archive_excel=bs_content.find("add", {"key": "archive_excel"}).get('value')  
    locationOfExcel=bs_content.find("add", {"key": "locationOfExcel"}).get('value')  
    locationOfArchiveExcel=bs_content.find("add", {"key": "locationOfArchiveExcel"}).get('value')  
    openExcel=bs_content.find("add", {"key": "open_excel"}).get('value')  

# Example data
# Try to do as much processing outside of initializing the workbook
# Everything beetween Workbook() and close() gets trapped in an exception
#random_data = [random.random() for _ in range(10)]
Date=df["Date"]
Inflows=df["Inflows"]
InflowsTributary=df["InflowsTributary"]
InflowsTributary2=df["InflowsTributary2"]

Precipitation1=df["Fierze_rain"]
Precipitation2=df["Koman_rain"]
Precipitation3=df["VauDejes_rain"]

Temperature1=df["Fierze_temp"]
Temperature2=df["Koman_temp"]
Temperature3=df["VauDejes_temp"]

Humidity1=df["Fierze_humi"]
Humidity2=df["Koman_humi"]
Humidity3=df["VauDejes_humi"]

offset_inflow=9
offset_precipitation=0
offset_temperature=3
offset_humidity=6
# Data location inside excel

data_start_loc_precipitation = [1+offset_precipitation, 1]
data_start_loc_precipitation1 = [2+offset_precipitation, 1]
data_start_loc_precipitation2= [3+offset_precipitation, 1]

data_start_loc_temperature = [1+offset_temperature, 1]
data_start_loc_temperature1 = [2+offset_temperature, 1]
data_start_loc_temperature2= [3+offset_temperature, 1]

data_start_loc_humidity = [1+offset_humidity, 1]
data_start_loc_humidity1 = [2+offset_humidity, 1]
data_start_loc_humidity2= [3+offset_humidity, 1]

data_start_loc_date = [0+offset_precipitation, 1] # xlsxwriter rquires list, no tuple
data_start_loc_inflows = [1+offset_inflow, 1]
data_start_loc_inflowstributary = [2+offset_inflow, 1]
data_start_loc_inflowstributary2= [3+offset_inflow, 1]

data_end_loc_precipitation = [1+offset_precipitation,data_start_loc_precipitation[0] + len(df.index)]
data_end_loc_precipitation1 = [2+offset_precipitation,data_start_loc_precipitation1[0] + len(df.index)]
data_end_loc_precipitation2 = [3+offset_precipitation,data_start_loc_precipitation2[0] + len(df.index)]

data_end_loc_temperature = [1+offset_temperature,data_start_loc_temperature[0] + len(df.index)]
data_end_loc_temperature1 = [2+offset_temperature,data_start_loc_temperature1[0] + len(df.index)]
data_end_loc_temperature2 = [3+offset_temperature,data_start_loc_temperature2[0] + len(df.index)]

data_end_loc_humidity = [1+offset_humidity,data_start_loc_humidity[0] + len(df.index)]
data_end_loc_humidity1 = [2+offset_humidity,data_start_loc_humidity1[0] + len(df.index)]
data_end_loc_humidity2 = [3+offset_humidity,data_start_loc_humidity2[0] + len(df.index)]


data_end_loc_inflows = [1+offset_inflow,data_start_loc_inflows[0] + len(df.index)]
data_end_loc_inflowstributary = [2+offset_inflow,data_start_loc_inflows[0] + len(df.index)]
data_end_loc_inflowstributary2 = [3+offset_inflow,data_start_loc_inflows[0] + len(df.index)]
workbook = xlsxwriter.Workbook(locationOfExcel)



worksheet = workbook.add_worksheet()

# A chart requires data to reference data inside excel
worksheet.write(offset_precipitation, 0, "Date") 
worksheet.write(offset_inflow+1, 0, "Inflows") 
worksheet.write(offset_inflow+2, 0, "InflowsTributary") 
worksheet.write(offset_inflow+3, 0, "InflowsTributary2") 

worksheet.write(offset_precipitation+1, 0, "Fierze_rain") 
worksheet.write(offset_precipitation+2, 0, "Koman_rain") 
worksheet.write(offset_precipitation+3, 0, "VauDejes_rain") 

worksheet.write(offset_temperature+1, 0, "Fierze_temperature") 
worksheet.write(offset_temperature+2, 0, "Koman_temperature") 
worksheet.write(offset_temperature+3, 0, "VauDejes_temperature") 

worksheet.write(offset_humidity+1, 0, "Fierze_humidity") 
worksheet.write(offset_humidity+2, 0, "Koman_humidity") 
worksheet.write(offset_humidity+3, 0, "VauDejes_humidity") 


worksheet.set_column(0, 0, 20) 

worksheet.write_row(*data_start_loc_precipitation, data=Precipitation1)
worksheet.write_row(*data_start_loc_precipitation1, data=Precipitation2)
worksheet.write_row(*data_start_loc_precipitation2, data=Precipitation3)

worksheet.write_row(*data_start_loc_temperature, data=Temperature1)
worksheet.write_row(*data_start_loc_temperature1, data=Temperature2)
worksheet.write_row(*data_start_loc_temperature2, data=Temperature3)

worksheet.write_row(*data_start_loc_humidity, data=Humidity1)
worksheet.write_row(*data_start_loc_humidity1, data=Humidity2)
worksheet.write_row(*data_start_loc_humidity2, data=Humidity3)

worksheet.write_row(*data_start_loc_date, data=Date)
worksheet.write_row(*data_start_loc_inflows, data=Inflows)
worksheet.write_row(*data_start_loc_inflowstributary, data=InflowsTributary)
worksheet.write_row(*data_start_loc_inflowstributary2, data=InflowsTributary2)

# Charts are independent of worksheets
chart = workbook.add_chart({'type': 'line'})
chart.set_y_axis({'name': 'inflow[m^3/s]'})
chart.set_x_axis({'name': 'hours'})
chart.set_title({'name': 'Inflows forecast'})
# The chart needs to explicitly reference data
chart.add_series({
    'values': [worksheet.name] + data_start_loc_inflows + data_end_loc_inflows,  
    'name': "Inflow Fierze",
})
chart.add_series({
    'values': [worksheet.name] + data_start_loc_inflowstributary + data_end_loc_inflowstributary,  
    'name': "Inflow Koman",
})
chart.add_series({
    'values': [worksheet.name] + data_start_loc_inflowstributary2 + data_end_loc_inflowstributary2,  
    'name': "Inflow Vau Dajes",
})
worksheet.insert_chart('B'+str(5+offset_inflow), chart, {'x_scale':2.7, 'y_scale': 1.5})


# Charts are independent of worksheets
chart2 = workbook.add_chart({'type': 'column'})
chart2.set_y_axis({'name': 'precipitation[mm]'})
chart2.set_x_axis({'name': 'hours'})
chart2.set_title({'name': 'Precipitation forecast'})
# The chart needs to explicitly reference data
chart2.add_series({
    'values': [worksheet.name] + data_start_loc_precipitation + data_end_loc_precipitation,  
    'name': "Precipitation Fierze",
})
chart2.add_series({
    'values': [worksheet.name] + data_start_loc_precipitation1 + data_end_loc_precipitation1,  
    'name': "Precipitation Koman",
})
chart2.add_series({
    'values': [worksheet.name] + data_start_loc_precipitation2 + data_end_loc_precipitation2,  
    'name': "Precipitation Vau Dajes",
})
worksheet.insert_chart('B'+str(30+offset_inflow), chart2, {'x_scale':2.2, 'y_scale': 1.5})

month_dry = pd.read_csv('measurments/dry_year.csv')
month_wet = pd.read_csv('measurments/wet_year.csv')
month_char = pd.read_csv('measurments/characteristic_year.csv')

currentMonth = datetime.now().month
month_dry['Datetime'] =  pd.to_datetime(month_dry['Datetime'], errors='coerce', dayfirst=True)
month_wet['Datetime'] =  pd.to_datetime(month_wet['Datetime'],errors='coerce', dayfirst=True)
month_char['Datetime'] =  pd.to_datetime(month_char['Datetime'],errors='coerce', dayfirst=True)
month_dry = month_dry[month_dry['Datetime'].dt.month == currentMonth]
month_wet = month_wet[month_wet['Datetime'].dt.month == currentMonth]
month_char = month_char[month_char['Datetime'].dt.month == currentMonth]
date=month_dry.index+1

dry1=month_dry["1_FierzaStorage"]
wet1=month_wet["1_FierzaStorage"]
char1=month_char["1_FierzaStorage"]
dry2=month_dry["2_KomanStorage"]
wet2=month_wet["2_KomanStorage"]
char2=month_char["2_KomanStorage"]
dry3=month_dry["3_VDejesStorage"]
wet3=month_wet["3_VDejesStorage"]
char3=month_char["3_VDejesStorage"]
worksheet = workbook.add_worksheet()

offset_Fierza=0

data_start_loc_date = [0+offset_Fierza, 1] # xlsxwriter rquires list, no tuple
data_start_loc_dry1 = [1+offset_Fierza, 1]
data_start_loc_dry2 = [2+offset_Fierza, 1]
data_start_loc_dry3= [3+offset_Fierza, 1]
data_end_loc_dry1 = [1+offset_Fierza, len(month_dry.index)]
data_end_loc_dry2 = [2+offset_Fierza, len(month_dry.index)]
data_end_loc_dry3 = [3+offset_Fierza, len(month_dry.index)]


worksheet.write(offset_Fierza, 0, "Day in month") 
worksheet.write(offset_Fierza+1, 0, "Fierza dry") 
worksheet.write(offset_Fierza+2, 0, "Fierza wet") 
worksheet.write(offset_Fierza+3, 0, "Fierza char") 


worksheet.write_row(*data_start_loc_date, data=date)
worksheet.write_row(*data_start_loc_dry1, data=dry1)
worksheet.write_row(*data_start_loc_dry2, data=wet1)
worksheet.write_row(*data_start_loc_dry3, data=char1)

# Charts are independent of worksheets
chart = workbook.add_chart({'type': 'line'})
chart.set_y_axis({'name': 'inflow[m^3/s]'})
chart.set_x_axis({'name': 'hours'})
chart.set_title({'name': 'Fierze current month statistics'})
# The chart needs to explicitly reference data
chart.add_series({
    'values': [worksheet.name] + data_start_loc_dry1 + data_end_loc_dry1,  
    'name': " Fierze dry",
})
chart.add_series({
    'values': [worksheet.name] + data_start_loc_dry2 + data_end_loc_dry2,  
    'name': "Fierze wet",
})
chart.add_series({
    'values': [worksheet.name] + data_start_loc_dry3 + data_end_loc_dry3,  
    'name': "Fierze characteristic",
})
worksheet.insert_chart('B'+str(20+offset_Fierza), chart, {'x_scale':2.7, 'y_scale': 1.5})


offset_Koman=5

data_start_loc_date = [0+offset_Koman, 1] # xlsxwriter rquires list, no tuple
data_start_loc_dry11 = [1+offset_Koman, 1]
data_start_loc_dry21 = [2+offset_Koman, 1]
data_start_loc_dry31= [3+offset_Koman, 1]
data_end_loc_dry11 = [1+offset_Koman, len(month_dry.index)]
data_end_loc_dry21 = [2+offset_Koman, len(month_dry.index)]
data_end_loc_dry31 = [3+offset_Koman,len(month_dry.index)]


worksheet.write(offset_Koman, 0, "Date") 
worksheet.write(offset_Koman+1, 0, "Koman dry") 
worksheet.write(offset_Koman+2, 0, "Koman wet") 
worksheet.write(offset_Koman+3, 0, "Koman char") 



worksheet.write_row(*data_start_loc_dry11, data=dry2)
worksheet.write_row(*data_start_loc_dry21, data=wet2)
worksheet.write_row(*data_start_loc_dry31, data=char2)

# Charts are independent of worksheets
chart = workbook.add_chart({'type': 'line'})
chart.set_y_axis({'name': 'inflow[m^3/s]'})
chart.set_x_axis({'name': 'hours'})
chart.set_title({'name': 'Koman current month statistics'})
# The chart needs to explicitly reference data
chart.add_series({
    'values': [worksheet.name] + data_start_loc_dry11 + data_end_loc_dry11,  
    'name': " Koman dry",
})
chart.add_series({
    'values': [worksheet.name] + data_start_loc_dry21 + data_end_loc_dry21,  
    'name': "Koman wet",
})
chart.add_series({
    'values': [worksheet.name] + data_start_loc_dry31 + data_end_loc_dry31,  
    'name': "Koman characteristic",
})
worksheet.insert_chart('B'+str(40+offset_Koman), chart, {'x_scale':2.7, 'y_scale': 1.5})

offset_VauDejes=10

data_start_loc_date = [0+offset_VauDejes, 1] # xlsxwriter rquires list, no tuple
data_start_loc_dry12 = [1+offset_VauDejes, 1]
data_start_loc_dry22 = [2+offset_VauDejes, 1]
data_start_loc_dry32= [3+offset_VauDejes, 1]
data_end_loc_dry12 = [1+offset_VauDejes, len(month_dry.index)]
data_end_loc_dry22 = [2+offset_VauDejes, len(month_dry.index)]
data_end_loc_dry32 = [3+offset_VauDejes,len(month_dry.index)]


worksheet.write(offset_VauDejes, 0, "Date") 
worksheet.write(offset_VauDejes+1, 0, "VauDejes dry") 
worksheet.write(offset_VauDejes+2, 0, "VauDejes wet") 
worksheet.write(offset_VauDejes+3, 0, "VauDejes char") 



worksheet.write_row(*data_start_loc_dry12, data=dry3)
worksheet.write_row(*data_start_loc_dry22, data=wet3)
worksheet.write_row(*data_start_loc_dry32, data=char3)

# Charts are independent of worksheets
chart = workbook.add_chart({'type': 'line'})
chart.set_y_axis({'name': 'inflow[m^3/s]'})
chart.set_x_axis({'name': 'hours'})
chart.set_title({'name': 'VauDejes current month statistics'})
# The chart needs to explicitly reference data
chart.add_series({
    'values': [worksheet.name] + data_start_loc_dry12 + data_end_loc_dry12,  
    'name': " VauDejes dry",
})
chart.add_series({
    'values': [worksheet.name] + data_start_loc_dry22 + data_end_loc_dry22,  
    'name': "VauDejes wet",
})
chart.add_series({
    'values': [worksheet.name] + data_start_loc_dry32 + data_end_loc_dry32,  
    'name': "VauDejes characteristic",
})
worksheet.insert_chart('B'+str(60+offset_VauDejes), chart, {'x_scale':2.7, 'y_scale': 1.5})

workbook.close()
if(archive_excel.lower()=='true'):
    workbook = xlsxwriter.Workbook(locationOfArchiveExcel+"\\excel_"+datetime.now().strftime("%Y%m%d%H%M%S")+".xslx")
    
  # Write to file
workbook.close()

df = pd.read_csv('AllDetails.csv')
cols_to_keep = ['Date', 'Inflows', 'InflowsTributary','InflowsTributary2']
df=df[cols_to_keep]
df = df.rename(columns={'Inflows': '1_FierzaStorage', 'InflowsTributary': '2_KomanStorage','Date': 'DATETIME', 'InflowsTributary2': '3_VDejesStorage'})
# df['DATETIME'] = df['DATETIME'].dt.strftime('%Y/%m/%d %H:%M:%S')
df=df.iloc[96:]
df.to_csv(CSV_location, index=False) 

if(openExcel.lower()=='true'):
    os.startfile(locationOfExcel)